// JavaScript Document
function changewidth(){
    var inputElemen = document.getElementById("inputmenu");
    if (inputElemen.style.width === "" || inputElemen.style.width === "12.5%"){
        inputElemen.style.width="80%";
    }
    else{
        inputElemen.style.width="12.5%";
    }
}
